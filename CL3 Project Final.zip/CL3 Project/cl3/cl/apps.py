from django.apps import AppConfig


class ClConfig(AppConfig):
    name = 'cl'
